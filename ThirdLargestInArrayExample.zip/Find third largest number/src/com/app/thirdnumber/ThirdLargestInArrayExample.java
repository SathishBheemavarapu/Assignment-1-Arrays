package com.app.thirdnumber;

	public class ThirdLargestInArrayExample{  
		public static int getThirdLargest(int[] a, int total){  
		int tem;  
		for (int i = 0; i < total; i++)   
		        {  
		            for (int j = i + 1; j < total; j++)   
		            {  
		                if (a[i] > a[j])   
		                {  
		                    tem = a[i];  
		                    a[i] = a[j];  
		                    a[j] = tem;  
		                }  
		            }  
		        }  
		       return a[total-3];  
		}  
		public static void main(String args[]){  
		int a[]={6, 8, 1, 9, 2, 1, 10};   
		System.out.println("Third largest element: "+getThirdLargest(a, 7)); 
		int b[]={6, 8, 1, 9, 2, 1, 10, 12};
		System.out.println("Third largest element: "+getThirdLargest(b, 8)); 
		int c[]= {6};
		System.out.println("Third largest element: "+getThirdLargest(c, 1));
		
		
		
		}}  


